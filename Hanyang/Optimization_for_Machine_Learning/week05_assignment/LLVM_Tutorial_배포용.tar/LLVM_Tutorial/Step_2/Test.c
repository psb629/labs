#include <stdio.h>

int func1(void)
{
	int a = 4;

	return a;
}

int main(void)
{
	return 0;
}
